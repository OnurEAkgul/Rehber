﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Rehber.API.Controllers
{
    // https://localhost:xxxx/api/rehber
    [Route("api/[controller]")]
    [ApiController]
    public class RehberController : ControllerBase
    {


        [HttpPost]   
        public async Task<IActionResult> CreateRehber()
        {

        }
    }
}
